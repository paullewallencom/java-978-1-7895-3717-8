package com.packt.datastructuresandalg.lesson1.activity.octaltodecimal;

public class OctalToDecimal {
    public int convertToDecimal(String octal) {
        return 999;
    }
}
