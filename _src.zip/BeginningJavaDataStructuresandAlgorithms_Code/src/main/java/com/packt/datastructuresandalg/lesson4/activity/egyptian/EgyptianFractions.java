package com.packt.datastructuresandalg.lesson4.activity.egyptian;

import java.util.List;

public class EgyptianFractions {
    public List<Long> build(Long numerator, Long denominator) { return null; }
}
