package com.packt.datastructuresandalg.lesson4.activity.maxsubarray;

public class MaximumSubarray {
    public Integer maxSubarray(int[] a) { return null; }
}
