package com.packt.datastructuresandalg.lesson4.activity.coinchange;

public class CoinChange {
    public Integer ways(int N, int[] coins) { return null; }
}
