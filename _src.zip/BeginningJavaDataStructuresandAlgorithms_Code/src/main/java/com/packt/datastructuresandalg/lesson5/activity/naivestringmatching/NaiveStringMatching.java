package com.packt.datastructuresandalg.lesson5.activity.naivestringmatching;

import java.util.List;

public class NaiveStringMatching {
    public List<Integer> match(String P, String T) { return null; }
}
