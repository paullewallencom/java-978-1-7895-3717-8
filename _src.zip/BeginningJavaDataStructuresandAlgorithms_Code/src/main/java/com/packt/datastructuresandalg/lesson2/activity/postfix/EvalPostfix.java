package com.packt.datastructuresandalg.lesson2.activity.postfix;

public class EvalPostfix {
    public double evaluate(String postfix) {
        return 0.0;
    }
}
