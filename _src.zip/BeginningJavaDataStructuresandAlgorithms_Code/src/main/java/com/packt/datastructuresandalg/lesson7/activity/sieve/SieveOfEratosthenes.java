package com.packt.datastructuresandalg.lesson7.activity.sieve;

public class SieveOfEratosthenes {
    public SieveOfEratosthenes(int maxValue) {
        // Build the sieve here
    }

    public boolean isPrime(int value) {
        return false;
    }
}
