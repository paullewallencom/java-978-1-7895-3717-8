package com.packt.datastructuresandalg.lesson5.activity.boyermoore;

import java.util.List;

public class BoyerMoore {
    public List<Integer> match(String P, String T) { return null; }
}
