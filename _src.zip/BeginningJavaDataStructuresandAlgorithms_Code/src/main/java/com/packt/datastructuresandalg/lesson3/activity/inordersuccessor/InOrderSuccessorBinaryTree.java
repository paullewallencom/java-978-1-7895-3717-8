package com.packt.datastructuresandalg.lesson3.activity.inordersuccessor;

import com.packt.datastructuresandalg.lesson3.binarytree.SimpleBinaryTree;

import java.util.Optional;

public class InOrderSuccessorBinaryTree<K,V> extends SimpleBinaryTree<K,V> {
    public Optional<K> inOrderSuccessorKey(K key) {
        return null;
    }
}
